exports.handler =  async function(event, context) {
	console.log('Hello from signed code');

	return context.logStreamName
  }
